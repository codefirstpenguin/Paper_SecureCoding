//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Implementation of LEA Block Cipher on 8-bit AVR Processors (Balanced Optimization)                           //
// Copyright (C) 2015 KISA <http://www.kisa.or.kr>                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include "LEA_core.h"

void LEA_Key(BYTE pbUserKey[16],DWORD pdwRoundKey[24][6]){
	
	DWORD delta[4] = {0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec};
	DWORD T[4] = {0x0,};
  int i;

	T[0] = DWORD_in(pbUserKey);
	T[1] = DWORD_in(pbUserKey + 4);
	T[2] = DWORD_in(pbUserKey + 8);
	T[3] = DWORD_in(pbUserKey + 12);

	for(i=0; i<24; i++) 
	{
		T[0] = ROL(T[0] + ROL(delta[i&3], i), 1);
		T[1] = ROL(T[1] + ROL(delta[i&3], i+1), 3);
		T[2] = ROL(T[2] + ROL(delta[i&3], i+2), 6);
		T[3] = ROL(T[3] + ROL(delta[i&3], i+3), 11);

		pdwRoundKey[i][0] = T[0];
		pdwRoundKey[i][1] = T[1];
		pdwRoundKey[i][2] = T[2];
		pdwRoundKey[i][3] = T[1];
		pdwRoundKey[i][4] = T[3];
		pdwRoundKey[i][5] = T[1];
	}
}

void LEA_Enc(DWORD pdwRoundKey[24][6],BYTE pbData[16])
{
	DWORD X0,X1,X2,X3;
	DWORD temp;
 int i;

	X0 = DWORD_in(pbData);
	X1 = DWORD_in(pbData + 4);
	X2 = DWORD_in(pbData + 8);
	X3 = DWORD_in(pbData + 12);

	for(i=0; i<24; i++)
	{
		X3 = ROR((X2 ^ pdwRoundKey[i][4]) + (X3 ^ pdwRoundKey[i][5]), 3);
		X2 = ROR((X1 ^ pdwRoundKey[i][2]) + (X2 ^ pdwRoundKey[i][3]), 5);
		X1 = ROL((X0 ^ pdwRoundKey[i][0]) + (X1 ^ pdwRoundKey[i][1]), 9);
		temp = X0;
		X0 = X1; X1 = X2; X2 = X3; X3 = temp;
	}

	DWORD_out(pbData, X0);
	DWORD_out(pbData + 4, X1);
	DWORD_out(pbData + 8, X2);
	DWORD_out(pbData + 12, X3);
}

void LEA_Dec(DWORD pdwRoundKey[24][6],BYTE pbData[16])
{
	DWORD X0,X1,X2,X3;
	DWORD temp;
 int i;

	X0 = DWORD_in(pbData);
	X1 = DWORD_in(pbData + 4);
	X2 = DWORD_in(pbData + 8);
	X3 = DWORD_in(pbData + 12);
	
	for(i=0; i<24; i++)
	{
		temp = X3;
		X3 = X2;
		X2 = X1;
		X1 = X0;
		X0 = temp;

		X1 = (ROR(X1,9) - (X0 ^ pdwRoundKey[24-1-i][0])) ^ pdwRoundKey[24-1-i][1];
		X2 = (ROL(X2,5) - (X1 ^ pdwRoundKey[24-1-i][2])) ^ pdwRoundKey[24-1-i][3];
		X3 = (ROL(X3,3) - (X2 ^ pdwRoundKey[24-1-i][4])) ^ pdwRoundKey[24-1-i][5];
	}

	DWORD_out(pbData, X0);
	DWORD_out(pbData + 4, X1);
	DWORD_out(pbData + 8, X2);
	DWORD_out(pbData + 12, X3);
}
